package com.example.myapplication1488

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    private lateinit var editTextNumber: EditText
    private lateinit var editTextResult: EditText
    private lateinit var button: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextNumber = findViewById(R.id.edit_text_number)
        editTextResult = findViewById(R.id.edit_text_result)
        button = findViewById(R.id.button)

        button.setOnClickListener {
            val input = editTextNumber.text.toString()

            if (input.isEmpty()) {
                editTextResult.setText("Введите число")
                return@setOnClickListener
            }

            try {
                val number = input.toInt()

                if (number < -2)
                {
                    editTextResult.setText((-5*number)-15)
                }
                else if (number >= -2 || number <= 2)
                {
                    editTextResult.setText((-number)*(-number))
                }
                else if (number > 2)
                {
                    editTextResult.setText("10")
                }


            } catch (e: NumberFormatException) {
                editTextResult.setText("Некорректный ввод")
            }
        }
    }

        }



